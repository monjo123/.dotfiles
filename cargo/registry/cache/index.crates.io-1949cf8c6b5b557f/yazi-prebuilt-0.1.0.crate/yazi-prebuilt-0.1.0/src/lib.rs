pub fn ansi_theme() -> &'static [u8] { include_bytes!("../built/ansi.tmTheme") }

pub fn syntaxes() -> &'static [u8] { include_bytes!("../built/syntaxes") }
