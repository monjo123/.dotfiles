# Prebuilt

This repo is used to place the pre-built assets of [Yazi](https://github.com/sxyazi/yazi).

```bash
cargo run --features build_deps
```

## Credits

- [bat](https://github.com/sharkdp/bat) - A cat(1) clone with wings.
