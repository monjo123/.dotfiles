return {"result from lua_dependency"}
